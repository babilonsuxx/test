-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 21, 2020 at 08:00 PM
-- Server version: 5.7.21-20-beget-5.7.21-20-1-log
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dimaneo_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `dataTable`
--
-- Creation: May 15, 2020 at 02:08 PM
--

DROP TABLE IF EXISTS `dataTable`;
CREATE TABLE `dataTable` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `title` text NOT NULL,
  `count` int(11) NOT NULL,
  `distance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dataTable`
--

INSERT INTO `dataTable` (`id`, `date`, `title`, `count`, `distance`) VALUES
(1, '2012-12-20', 'Цюрих', 1, 2),
(2, '2012-12-20', 'Рим', 1, 2),
(3, '2012-12-20', 'Лиссабон', 1, 2),
(4, '2012-12-20', 'Вена', 1, 2),
(5, '2012-12-20', 'Валлетта', 1, 2),
(6, '2012-12-20', 'Берн', 1, 2),
(7, '2012-12-20', 'Стокгольм', 6, 3),
(8, '2012-12-20', 'Минск', 6, 3),
(9, '2012-12-20', 'Дублин', 6, 3),
(10, '2012-12-20', 'Вадуц', 6, 3),
(11, '2012-12-20', 'Белград', 6, 3),
(12, '2012-12-20', 'Амстердам', 6, 3),
(13, '2012-12-20', 'Тирана', 22, 12),
(14, '2012-12-20', 'Скопье', 22, 12),
(15, '2012-12-20', 'Сараево', 22, 12),
(16, '2012-12-20', 'Мадрид', 22, 12),
(17, '2012-12-20', 'Киев', 22, 12),
(18, '2012-12-20', 'Варшава', 22, 12),
(19, '2012-12-20', 'София', 33, 25),
(20, '2012-12-20', 'Рига', 33, 25),
(21, '2012-12-20', 'Лондон', 33, 25),
(22, '2012-12-20', 'Кишинев', 33, 25),
(23, '2012-12-20', 'Бухарест', 33, 25),
(24, '2012-12-20', 'Афины', 33, 25),
(25, '2012-12-20', 'Сан-Марино', 12, 77),
(26, '2012-12-20', 'Монако', 12, 77),
(27, '2012-12-20', 'Копенгаген', 12, 77),
(28, '2012-12-20', 'Вильнюс', 12, 77),
(29, '2012-12-20', 'Брюссель', 12, 77),
(30, '2012-12-20', 'Берлин', 12, 77),
(31, '2012-12-20', 'Рейкьявик', 4, 86),
(32, '2012-12-20', 'Осло', 4, 86),
(33, '2012-12-20', 'Люксембург', 4, 86),
(34, '2012-12-20', 'Ватикан', 4, 86),
(35, '2012-12-20', 'Братислава', 4, 86),
(36, '2012-12-20', 'Андорра-ла-Велья', 4, 86);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dataTable`
--
ALTER TABLE `dataTable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dataTable`
--
ALTER TABLE `dataTable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
